/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, WaterLog, StepLog, WeightLog, SleepLog, Reminder, DietPlan } from './types';
import Dashboard from './components/Dashboard';
import WaterAndSteps from './components/WaterAndSteps';
import WeightAndSleep from './components/WeightAndSleep';
import DietPlanAI from './components/DietPlanAI';
import BMIAndCalorie from './components/BMIAndCalorie';
import Reminders from './components/Reminders';
import {
  Heart,
  Grid,
  Activity,
  ChefHat,
  Bell,
  User,
  Moon,
  Sun,
  Smartphone,
  Wifi,
  Battery,
  ShieldCheck,
  RotateCcw,
  Volume2,
  Trash2,
  Save,
  Clock,
  LogOut,
  Sparkles,
} from 'lucide-react';

// Help helper for date offset
const getPastDateString = (daysAgo: number) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
};

export default function App() {
  // ----------------------------------------------------
  // STATES & STATE SYNCS WITH LOCALSTORAGE
  // ----------------------------------------------------
  const [profile, setProfile] = useState<UserProfile>(() => {
    const raw = localStorage.getItem('fittakip_profile');
    if (raw) return JSON.parse(raw);
    return {
      name: 'Caner',
      age: 26,
      gender: 'male',
      height: 180,
      weight: 79.5,
      activityLevel: 'moderate',
      weightGoal: 'lose',
      dailyWaterTarget: 2500,
      dailyStepTarget: 10000,
      dailyCalorieTarget: 2150,
      dailySleepTarget: 8,
    };
  });

  const [waterLogs, setWaterLogs] = useState<WaterLog[]>(() => {
    const raw = localStorage.getItem('fittakip_water');
    if (raw) return JSON.parse(raw);
    // Seed today's water logs
    return [
      { id: 'w1', amount: 500, timestamp: new Date(Date.now() - 5 * 3600000).toISOString() },
      { id: 'w2', amount: 250, timestamp: new Date(Date.now() - 3 * 3600000).toISOString() },
      { id: 'w3', amount: 500, timestamp: new Date(Date.now() - 1 * 3600000).toISOString() },
    ];
  });

  const [stepLogs, setStepLogs] = useState<StepLog[]>(() => {
    const raw = localStorage.getItem('fittakip_steps');
    if (raw) return JSON.parse(raw);
    // Seed last 7 days of steps
    return [
      { id: 's1', steps: 8500, date: getPastDateString(6) },
      { id: 's2', steps: 11200, date: getPastDateString(5) },
      { id: 's3', steps: 9400, date: getPastDateString(4) },
      { id: 's4', steps: 10100, date: getPastDateString(3) },
      { id: 's5', steps: 7200, date: getPastDateString(2) },
      { id: 's6', steps: 10800, date: getPastDateString(1) },
      { id: 's7', steps: 6400, date: getPastDateString(0) }, // Today
    ];
  });

  const [weightLogs, setWeightLogs] = useState<WeightLog[]>(() => {
    const raw = localStorage.getItem('fittakip_weight');
    if (raw) return JSON.parse(raw);
    // Seed downward trend weight logs
    return [
      { id: 'wt1', weight: 81.2, date: getPastDateString(14) },
      { id: 'wt2', weight: 80.8, date: getPastDateString(10) },
      { id: 'wt3', weight: 80.4, date: getPastDateString(7) },
      { id: 'wt4', weight: 80.0, date: getPastDateString(4) },
      { id: 'wt5', weight: 79.7, date: getPastDateString(2) },
      { id: 'wt6', weight: 79.5, date: getPastDateString(0) }, // Today
    ];
  });

  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>(() => {
    const raw = localStorage.getItem('fittakip_sleep');
    if (raw) return JSON.parse(raw);
    // Seed last 7 days of sleep
    return [
      { id: 'sl1', duration: 7.5, quality: 'good', date: getPastDateString(6) },
      { id: 'sl2', duration: 8.0, quality: 'good', date: getPastDateString(5) },
      { id: 'sl3', duration: 6.5, quality: 'average', date: getPastDateString(4) },
      { id: 'sl4', duration: 8.5, quality: 'good', date: getPastDateString(3) },
      { id: 'sl5', duration: 7.0, quality: 'good', date: getPastDateString(2) },
      { id: 'sl6', duration: 6.0, quality: 'poor', date: getPastDateString(1) },
      { id: 'sl7', duration: 7.5, quality: 'good', date: getPastDateString(0) }, // Today
    ];
  });

  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const raw = localStorage.getItem('fittakip_reminders');
    if (raw) return JSON.parse(raw);
    // Seed standard Turkish reminders
    return [
      { id: 'rem1', title: 'Güne Başlarken Su İç 💧', time: '08:30', active: true, type: 'water' },
      { id: 'rem2', title: 'Öğle Arası Duruş Esnemesi 🤸‍♂️', time: '12:30', active: true, type: 'stretch' },
      { id: 'rem3', title: 'Günü Tamamlama Su Kontrolü 💧', time: '17:30', active: true, type: 'water' },
      { id: 'rem4', title: 'Gece Uykusuna Hazırlık 🌙', time: '22:30', active: true, type: 'sleep' },
    ];
  });

  const [savedDietPlans, setSavedDietPlans] = useState<DietPlan[]>(() => {
    const raw = localStorage.getItem('fittakip_dietplans');
    if (raw) return JSON.parse(raw);
    return [];
  });

  const [activeDietPlanId, setActiveDietPlanId] = useState<string | null>(() => {
    const raw = localStorage.getItem('fittakip_active_diet_id');
    return raw || 'preset-akdeniz';
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'trackers' | 'diet' | 'bmi' | 'reminders' | 'profile'>('dashboard');
  const [trackerSubTab, setTrackerSubTab] = useState<'water_steps' | 'weight_sleep'>('water_steps');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const raw = localStorage.getItem('fittakip_darkmode');
    return raw === 'true';
  });

  // ----------------------------------------------------
  // SIMULATED ALARMS SYSTEM (WEB AUDIO SINE SYNTHESIS)
  // ----------------------------------------------------
  const [ringingAlarm, setRingingAlarm] = useState<Reminder | null>(null);
  const lastTriggeredTimeRef = useRef<string>('');

  // Save states back to localstorage when modified
  useEffect(() => {
    localStorage.setItem('fittakip_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('fittakip_water', JSON.stringify(waterLogs));
  }, [waterLogs]);

  useEffect(() => {
    localStorage.setItem('fittakip_steps', JSON.stringify(stepLogs));
  }, [stepLogs]);

  useEffect(() => {
    localStorage.setItem('fittakip_weight', JSON.stringify(weightLogs));
  }, [weightLogs]);

  useEffect(() => {
    localStorage.setItem('fittakip_sleep', JSON.stringify(sleepLogs));
  }, [sleepLogs]);

  useEffect(() => {
    localStorage.setItem('fittakip_reminders', JSON.stringify(reminders));
  }, [reminders]);

  useEffect(() => {
    localStorage.setItem('fittakip_dietplans', JSON.stringify(savedDietPlans));
  }, [savedDietPlans]);

  useEffect(() => {
    localStorage.setItem('fittakip_active_diet_id', activeDietPlanId || '');
  }, [activeDietPlanId]);

  // Dark mode class syncing
  useEffect(() => {
    localStorage.setItem('fittakip_darkmode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // alarm background monitor (checks every second)
  useEffect(() => {
    const checkAlarm = setInterval(() => {
      const now = new Date();
      const currentHHMM = now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

      // Only check once per minute to avoid multiple triggers on the same minute
      if (lastTriggeredTimeRef.current !== currentHHMM) {
        const matchingActiveReminder = reminders.find(
          (rem) => rem.active && rem.time === currentHHMM
        );

        if (matchingActiveReminder) {
          lastTriggeredTimeRef.current = currentHHMM;
          setRingingAlarm(matchingActiveReminder);
          triggerBeepSequence();
        }
      }
    }, 1000);

    return () => clearInterval(checkAlarm);
  }, [reminders]);

  // Web Audio alarm synth double-beep sequence
  const triggerBeepSequence = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playBeep = (delay: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(660, audioCtx.currentTime + delay); // E5 note
        gainNode.gain.setValueAtTime(0, audioCtx.currentTime + delay);
        gainNode.gain.linearRampToValueAtTime(0.08, audioCtx.currentTime + delay + 0.02);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + delay + duration);
        osc.start(audioCtx.currentTime + delay);
        osc.stop(audioCtx.currentTime + delay + duration);
      };

      // Play double-beep
      playBeep(0, 0.25);
      playBeep(0.3, 0.25);
    } catch (e) {
      console.warn('Audio feedback failed or was blocked by browser policies.', e);
    }
  };

  // ----------------------------------------------------
  // MUTATION HANDLERS
  // ----------------------------------------------------
  const handleUpdateProfile = (newProfile: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...newProfile }));
  };

  const handleAddWater = (amount: number) => {
    const newLog: WaterLog = {
      id: `w-${Date.now()}`,
      amount,
      timestamp: new Date().toISOString(),
    };
    setWaterLogs((prev) => [...prev, newLog]);
    triggerBeepSequence();
  };

  const handleRemoveWaterLog = (id: string) => {
    setWaterLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleUpdateSteps = (steps: number) => {
    const todayStr = new Date().toISOString().split('T')[0];
    setStepLogs((prev) => {
      const updated = [...prev];
      const todayIndex = updated.findIndex((l) => l.date === todayStr);
      if (todayIndex >= 0) {
        updated[todayIndex] = { ...updated[todayIndex], steps };
      } else {
        updated.push({ id: `s-${Date.now()}`, steps, date: todayStr });
      }
      return updated;
    });
  };

  const handleAddWeightLog = (weight: number, date: string) => {
    // Check if date log already exists, if so update it, else append
    setWeightLogs((prev) => {
      const updated = [...prev];
      const existingIdx = updated.findIndex((l) => l.date === date);
      if (existingIdx >= 0) {
        updated[existingIdx] = { ...updated[existingIdx], weight };
      } else {
        updated.push({ id: `wt-${Date.now()}`, weight, date });
      }
      // Sort logs by date ascending
      return updated.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    });
    // Also update current profile weight
    setProfile((prev) => ({ ...prev, weight }));
  };

  const handleRemoveWeightLog = (id: string) => {
    setWeightLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleAddSleepLog = (duration: number, quality: SleepLog['quality'], date: string) => {
    setSleepLogs((prev) => {
      const updated = [...prev];
      const existingIdx = updated.findIndex((l) => l.date === date);
      if (existingIdx >= 0) {
        updated[existingIdx] = { ...updated[existingIdx], duration, quality };
      } else {
        updated.push({ id: `sl-${Date.now()}`, duration, quality, date });
      }
      return updated.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    });
  };

  const handleRemoveSleepLog = (id: string) => {
    setSleepLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleToggleReminder = (id: string) => {
    setReminders((prev) =>
      prev.map((rem) => (rem.id === id ? { ...rem, active: !rem.active } : rem))
    );
  };

  const handleAddReminder = (title: string, time: string, type: Reminder['type']) => {
    const newRem: Reminder = {
      id: `rem-${Date.now()}`,
      title,
      time,
      active: true,
      type,
    };
    setReminders((prev) => [...prev, newRem].sort((a, b) => a.time.localeCompare(b.time)));
  };

  const handleDeleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
  };

  const handleSaveNewDietPlan = (plan: DietPlan) => {
    setSavedDietPlans((prev) => [...prev, plan]);
  };

  const handleDeleteDietPlan = (id: string) => {
    setSavedDietPlans((prev) => prev.filter((p) => p.id !== id));
    if (activeDietPlanId === id) {
      setActiveDietPlanId('preset-akdeniz');
    }
  };

  // Reset App / Clean storage
  const handleResetApplication = () => {
    if (confirm('Bütün kaydedilmiş sağlık verilerinizi ve özel profilleri silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  // Load sample values
  const handleLoadSampleData = () => {
    localStorage.clear();
    window.location.reload();
  };

  // Active Diet Plan finder for dashboard link
  const currentActiveDiet = () => {
    if (activeDietPlanId?.startsWith('preset-')) {
      const presets = [
        {
          id: 'preset-akdeniz',
          title: 'Akdeniz Diyeti (Dengeli Yaşam)',
          type: 'preset',
          description: 'Sağlıklı yağlar, bol sebze, balık ve tam tahıllar içeren dengeli beslenme modeli.',
          meals: [
            { name: 'Haşlanmış Yumurtalı Kahvaltı', calories: 340, food: 'Yumurta, peynir, sebze' },
            { name: 'Zeytinyağlı Öğle Yemeği', calories: 420, food: 'Zeytinyağlı taze fasulye, yoğurt' }
          ]
        },
        {
          id: 'preset-aralikli-oruc',
          title: 'Aralıklı Oruç (16:8 Metodu)',
          type: 'preset',
          description: '16 saat açlık, 8 saatlik beslenme penceresi içeren popüler beslenme planı.',
          meals: []
        },
        {
          id: 'preset-protein',
          title: 'Kas Kazanımı (Yüksek Protein)',
          type: 'preset',
          description: 'Kas kütlesini korumak, onarmak ve geliştirmek isteyen sporcular veya aktif bireyler için diyet.',
          meals: []
        },
      ];
      return presets.find((p) => p.id === activeDietPlanId) as any;
    }
    return savedDietPlans.find((p) => p.id === activeDietPlanId);
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-black py-4 px-2 sm:px-4 flex items-center justify-center font-sans select-none antialiased">
      {/* ALARM POPUP MODAL (SIMULATED RINGING) */}
      {ringingAlarm && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex flex-col items-center justify-center p-6 text-white animate-fade-in text-center">
          <div className="bg-emerald-600/15 border border-emerald-500/30 p-6 rounded-full text-emerald-400 mb-6 animate-pulse">
            <Bell className="w-16 h-16" />
          </div>
          <p className="text-sm font-bold font-mono text-emerald-400 tracking-wider uppercase">
            FitTakip Alarm Çalıyor! ⏰
          </p>
          <h2 className="text-3xl font-extrabold font-sans tracking-tight mt-2 max-w-md leading-snug">
            {ringingAlarm.title}
          </h2>
          <p className="text-sm text-gray-300 font-mono mt-3 bg-gray-900/60 py-1.5 px-4 rounded-full border border-gray-800">
            Zamanlama: <strong className="text-white font-bold">{ringingAlarm.time}</strong>
          </p>

          <div className="mt-10 flex flex-col sm:flex-row gap-3 w-full max-w-xs">
            <button
              onClick={() => {
                setRingingAlarm(null);
                triggerBeepSequence();
              }}
              className="py-3 px-6 bg-emerald-500 hover:bg-emerald-600 active:scale-[0.98] transition-all rounded-xl font-bold text-sm shadow-md shadow-emerald-500/20"
            >
              Tamamlandı, Kapat ✔
            </button>
            <button
              onClick={() => {
                setRingingAlarm(null);
                // snooze alarm 5 mins later
                const [h, m] = ringingAlarm.time.split(':');
                const rawM = parseInt(m, 10);
                const snoozeM = (rawM + 5) % 60;
                const snoozeH = (parseInt(h, 10) + Math.floor((rawM + 5) / 60)) % 24;
                const formattedTime = `${String(snoozeH).padStart(2, '0')}:${String(snoozeM).padStart(2, '0')}`;
                
                handleAddReminder(
                  `${ringingAlarm.title} (Ertelenen)`,
                  formattedTime,
                  ringingAlarm.type
                );
                alert(`Alarm 5 dakika sonraya (${formattedTime}) ertelendi.`);
              }}
              className="py-3 px-6 bg-gray-800 hover:bg-gray-700 active:scale-[0.98] transition-all rounded-xl font-semibold text-xs border border-gray-700 text-gray-300"
            >
              5 Dk Ertele 🕒
            </button>
          </div>
        </div>
      )}

      {/* PHONE/MOCK APPLICATION CONTAINER */}
      <div className="w-full max-w-4xl bg-white dark:bg-gray-950 rounded-[36px] shadow-2xl border-4 border-gray-200 dark:border-gray-900 overflow-hidden relative flex flex-col lg:flex-row">
        
        {/* SIDE BAR / BRANDING PANEL - DESKTOP ONLY */}
        <div className="lg:w-72 bg-gradient-to-b from-emerald-950 to-teal-950 dark:from-black dark:to-gray-950 text-white p-6 flex flex-col justify-between border-r border-emerald-900/10 dark:border-gray-900 shrink-0">
          <div className="space-y-6">
            {/* Branding title */}
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-500 text-white rounded-2xl shadow-lg shadow-emerald-500/20">
                <Heart className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h1 className="text-xl font-extrabold tracking-tight font-sans text-emerald-400">
                  FitTakip
                </h1>
                <p className="text-[10px] text-emerald-200/60 font-mono">
                  AKILLI SAĞLIK REHBERİ
                </p>
              </div>
            </div>

            {/* Profile Glance widget */}
            <div className="bg-white/5 dark:bg-gray-900/50 rounded-2xl p-4 border border-white/5 space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-emerald-400/20 text-emerald-400 rounded-full flex items-center justify-center font-bold">
                  {profile.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-white">{profile.name}</h4>
                  <p className="text-[10px] text-emerald-200/50 font-mono">
                    {profile.weightGoal === 'lose' ? 'Hedef: Kilo Verme' : profile.weightGoal === 'gain' ? 'Hedef: Kilo Alma' : 'Hedef: Kiloyu Koruma'}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-3xs border-t border-white/5 pt-2 font-mono">
                <div>
                  <span className="text-gray-400">Boy:</span>{' '}
                  <span className="text-white font-bold">{profile.height} cm</span>
                </div>
                <div>
                  <span className="text-gray-400">Ağırlık:</span>{' '}
                  <span className="text-white font-bold">{profile.weight} kg</span>
                </div>
              </div>
            </div>

            {/* Navigation links - Desktop Sidebar */}
            <nav className="space-y-1.5 hidden lg:block">
              <span className="block text-[10px] text-emerald-200/40 uppercase tracking-widest font-extrabold pb-1">Kategoriler</span>
              {[
                { id: 'dashboard', label: 'Ana Sayfa', icon: Grid },
                { id: 'trackers', label: 'Sıvı & Kilo İzleyici', icon: Activity },
                { id: 'diet', label: 'Diyet & AI Planlayıcı', icon: ChefHat },
                { id: 'bmi', label: 'VKİ & Kalori Hesapla', icon: Smartphone },
                { id: 'reminders', label: 'Alarmlar & Hatırlatıcı', icon: Bell },
                { id: 'profile', label: 'Profil & Ayarlar', icon: User },
              ].map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id as any)}
                    className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center space-x-3 transition-all ${
                      isActive
                        ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20 font-bold'
                        : 'text-gray-300 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4.5 h-4.5 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Quick theme state */}
          <div className="space-y-3 pt-6 border-t border-white/5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-emerald-200/50">Gece Modu</span>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-1.5 bg-white/5 hover:bg-white/10 text-emerald-400 rounded-xl transition-all"
                title={darkMode ? 'Gündüz Moduna Geç' : 'Gece Moduna Geç'}
              >
                {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
            <div className="text-[9px] text-emerald-200/40 font-mono leading-none">
              FitTakip v1.0.0 · Türkçe
            </div>
          </div>
        </div>

        {/* WORKSPACE - MAIN PHONE DISPLAY VIEWPORT */}
        <div className="flex-1 flex flex-col min-w-0 bg-white dark:bg-gray-950">
          
          {/* MOCK PHONE TOP BAR */}
          <div className="px-5 py-2.5 bg-gray-50 dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center shrink-0">
            <div className="flex items-center space-x-1.5 font-mono text-[10px] font-extrabold text-gray-500 dark:text-gray-400">
              <Clock className="w-3.5 h-3.5" />
              <span>{new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            
            <div className="flex items-center space-x-1 lg:hidden">
              <Heart className="w-4 h-4 text-emerald-500 animate-pulse mr-1" />
              <span className="text-xs font-black text-gray-800 dark:text-white font-sans">FitTakip</span>
            </div>

            <div className="flex items-center space-x-2.5 text-gray-400 dark:text-gray-500">
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4" />
              <span className="text-[10px] font-extrabold font-mono text-gray-500 dark:text-gray-400">%85</span>
            </div>
          </div>

          {/* INTERNAL CONTENT SCROLL CONTAINER */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 scrollbar-thin">
            {activeTab === 'dashboard' && (
              <Dashboard
                profile={profile}
                waterLogs={waterLogs}
                stepLogs={stepLogs}
                weightLogs={weightLogs}
                sleepLogs={sleepLogs}
                activeDietPlan={currentActiveDiet()}
                onNavigateToTab={(tab) => setActiveTab(tab as any)}
                onQuickAddWater={handleAddWater}
                onQuickAddSteps={(stepsToAdd) => {
                  const todayStr = new Date().toISOString().split('T')[0];
                  const todayStepsLog = stepLogs.find((l) => l.date === todayStr);
                  const currentSteps = todayStepsLog ? todayStepsLog.steps : 0;
                  handleUpdateSteps(currentSteps + stepsToAdd);
                }}
              />
            )}

            {activeTab === 'trackers' && (
              <div className="space-y-5 animate-fade-in">
                {/* Custom Sub-tab segmented controller */}
                <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-2xl border border-gray-200/20 dark:border-gray-800/20">
                  <button
                    onClick={() => setTrackerSubTab('water_steps')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      trackerSubTab === 'water_steps'
                        ? 'bg-white dark:bg-gray-850 text-emerald-600 dark:text-emerald-400 shadow-sm'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                    }`}
                  >
                    Sıvı & Hareket Takibi
                  </button>
                  <button
                    onClick={() => setTrackerSubTab('weight_sleep')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      trackerSubTab === 'weight_sleep'
                        ? 'bg-white dark:bg-gray-850 text-emerald-600 dark:text-emerald-400 shadow-sm'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                    }`}
                  >
                    Kilo & Uyku Trendleri
                  </button>
                </div>

                {trackerSubTab === 'water_steps' ? (
                  <WaterAndSteps
                    profile={profile}
                    waterLogs={waterLogs}
                    stepLogs={stepLogs}
                    onAddWater={handleAddWater}
                    onRemoveWaterLog={handleRemoveWaterLog}
                    onUpdateSteps={handleUpdateSteps}
                  />
                ) : (
                  <WeightAndSleep
                    profile={profile}
                    weightLogs={weightLogs}
                    sleepLogs={sleepLogs}
                    onAddWeightLog={handleAddWeightLog}
                    onRemoveWeightLog={handleRemoveWeightLog}
                    onAddSleepLog={handleAddSleepLog}
                    onRemoveSleepLog={handleRemoveSleepLog}
                  />
                )}
              </div>
            )}

            {activeTab === 'diet' && (
              <DietPlanAI
                profile={profile}
                savedDietPlans={savedDietPlans}
                activeDietPlanId={activeDietPlanId}
                onSelectActiveDietPlan={setActiveDietPlanId}
                onSaveNewDietPlan={handleSaveNewDietPlan}
                onDeleteDietPlan={handleDeleteDietPlan}
              />
            )}

            {activeTab === 'bmi' && (
              <BMIAndCalorie
                profile={profile}
                onUpdateProfile={handleUpdateProfile}
              />
            )}

            {activeTab === 'reminders' && (
              <Reminders
                reminders={reminders}
                onToggleReminder={handleToggleReminder}
                onAddReminder={handleAddReminder}
                onDeleteReminder={handleDeleteReminder}
              />
            )}

            {activeTab === 'profile' && (
              <div className="space-y-6 animate-fade-in">
                {/* Title */}
                <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
                  <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
                      Kullanıcı Profili & Ayarlar
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                      Hesap tercihlerinizi ve hedeflerinizi yönetin
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Profile Edit Card */}
                  <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Kişisel Bilgiler</h3>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Adınız</label>
                        <input
                          type="text"
                          value={profile.name}
                          onChange={(e) => handleUpdateProfile({ name: e.target.value })}
                          className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Boy (cm)</label>
                          <input
                            type="number"
                            value={profile.height}
                            onChange={(e) => handleUpdateProfile({ height: Math.max(1, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Kilo (kg)</label>
                          <input
                            type="number"
                            value={profile.weight}
                            onChange={(e) => handleUpdateProfile({ weight: Math.max(1, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Yaş</label>
                          <input
                            type="number"
                            value={profile.age}
                            onChange={(e) => handleUpdateProfile({ age: Math.max(1, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Targets Card */}
                  <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Günlük Hedefler</h3>
                    
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Su Hedefi (ml)</label>
                          <input
                            type="number"
                            value={profile.dailyWaterTarget}
                            onChange={(e) => handleUpdateProfile({ dailyWaterTarget: Math.max(100, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Adım Hedefi</label>
                          <input
                            type="number"
                            value={profile.dailyStepTarget}
                            onChange={(e) => handleUpdateProfile({ dailyStepTarget: Math.max(100, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Kalori Hedefi (kcal)</label>
                          <input
                            type="number"
                            value={profile.dailyCalorieTarget}
                            onChange={(e) => handleUpdateProfile({ dailyCalorieTarget: Math.max(500, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Uyku Hedefi (saat)</label>
                          <input
                            type="number"
                            value={profile.dailySleepTarget}
                            onChange={(e) => handleUpdateProfile({ dailySleepTarget: Math.max(1, Number(e.target.value)) })}
                            className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* System Settings Block */}
                <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Sistem İşlemleri</h3>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      type="button"
                      onClick={handleLoadSampleData}
                      className="flex-1 py-2 px-4 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold rounded-xl border border-emerald-200/50 dark:border-emerald-900/50 transition-all flex items-center justify-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" /> Örnek Verileri Yenile
                    </button>
                    <button
                      type="button"
                      onClick={handleResetApplication}
                      className="flex-1 py-2 px-4 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-xl border border-rose-200/50 dark:border-rose-900/50 transition-all flex items-center justify-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" /> Tüm Verileri Temizle
                    </button>
                  </div>
                </div>

                {/* Privacy & Trust Badge */}
                <div className="p-4 bg-emerald-500/5 dark:bg-emerald-950/5 border border-emerald-500/10 dark:border-emerald-950/10 rounded-2xl flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h4 className="text-xs font-extrabold text-emerald-700 dark:text-emerald-400">
                      Yerel Gizlilik Politikası
                    </h4>
                    <p className="text-2xs text-gray-500 dark:text-gray-400 leading-relaxed font-sans">
                      FitTakip sağlık verilerinizin gizliliğine önem verir. Tüm su, adım, kilo ve uyku istatistikleriniz cihazınızda (tarayıcı yerel belleğinde) saklanır, hiçbir harici sunucuya iletilmez. Yapay zeka asistanı diyet planları oluşturmak için yalnızca yaş, cinsiyet ve ağırlık hedeflerinizi anonim olarak kullanır.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* MOCK PHONE BOTTOM NAV BAR - ON MOBILE VIEW ONLY */}
          <nav className="lg:hidden border-t border-gray-100 dark:border-gray-800 bg-gray-50/95 dark:bg-gray-900/95 backdrop-blur-md px-1 py-2 flex justify-around items-center shrink-0">
            {[
              { id: 'dashboard', label: 'Ana Sayfa', icon: Grid },
              { id: 'trackers', label: 'Takipçiler', icon: Activity },
              { id: 'diet', label: 'Diyet', icon: ChefHat },
              { id: 'bmi', label: 'VKİ/Kcal', icon: Smartphone },
              { id: 'reminders', label: 'Alarmlar', icon: Bell },
              { id: 'profile', label: 'Profil', icon: User },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`flex flex-col items-center justify-center space-y-1 py-1 px-2.5 rounded-xl transition-all ${
                    isActive
                      ? 'text-emerald-500 dark:text-emerald-400 font-bold scale-105'
                      : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="text-[9px] tracking-tight">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
