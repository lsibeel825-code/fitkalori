/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  height: number; // in cm
  weight: number; // in kg
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  weightGoal: 'lose' | 'maintain' | 'gain';
  dailyWaterTarget: number; // in ml
  dailyStepTarget: number;
  dailyCalorieTarget: number; // in kcal
  dailySleepTarget: number; // in hours
}

export interface WaterLog {
  id: string;
  amount: number; // in ml
  timestamp: string; // ISO string
}

export interface StepLog {
  id: string;
  steps: number;
  date: string; // YYYY-MM-DD
}

export interface WeightLog {
  id: string;
  weight: number;
  date: string; // YYYY-MM-DD
}

export interface SleepLog {
  id: string;
  duration: number; // in hours
  quality: 'good' | 'average' | 'poor';
  date: string; // YYYY-MM-DD
}

export interface Reminder {
  id: string;
  title: string;
  time: string; // HH:MM
  active: boolean;
  type: 'water' | 'stretch' | 'sleep' | 'custom';
}

export interface Meal {
  name: string; // Kahvaltı, Öğle Yemeği, vb.
  food: string;
  calories: number;
}

export interface DietPlan {
  id: string;
  title: string;
  type: 'preset' | 'ai';
  description: string;
  meals: Meal[];
  tips: string[];
}
