/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { Activity, Flame, Scale, Calculator, Info, CheckCircle2 } from 'lucide-react';

interface BMIAndCalorieProps {
  profile: UserProfile;
  onUpdateProfile: (profile: Partial<UserProfile>) => void;
}

export default function BMIAndCalorie({ profile, onUpdateProfile }: BMIAndCalorieProps) {
  // BMI Local State (initialized with profile or defaults)
  const [weight, setWeight] = useState<number>(profile.weight || 70);
  const [height, setHeight] = useState<number>(profile.height || 175);
  const [age, setAge] = useState<number>(profile.age || 28);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>(profile.gender || 'male');
  const [activity, setActivity] = useState<UserProfile['activityLevel']>(profile.activityLevel || 'moderate');
  const [goal, setGoal] = useState<UserProfile['weightGoal']>(profile.weightGoal || 'maintain');

  const [bmi, setBmi] = useState<number>(0);
  const [bmiCategory, setBmiCategory] = useState<string>('');
  const [bmiColor, setBmiColor] = useState<string>('');
  const [idealWeightRange, setIdealWeightRange] = useState<{ min: number; max: number }>({ min: 0, max: 0 });

  const [bmr, setBmr] = useState<number>(0);
  const [tdee, setTdee] = useState<number>(0);
  const [targetCalories, setTargetCalories] = useState<number>(0);

  // Sync state if profile changes externally
  useEffect(() => {
    if (profile.weight) setWeight(profile.weight);
    if (profile.height) setHeight(profile.height);
    if (profile.age) setAge(profile.age);
    if (profile.gender) setGender(profile.gender);
    if (profile.activityLevel) setActivity(profile.activityLevel);
    if (profile.weightGoal) setGoal(profile.weightGoal);
  }, [profile]);

  // Recalculate BMI & Calorie Needs
  useEffect(() => {
    // BMI
    const heightInMeters = height / 100;
    const computedBmi = weight / (heightInMeters * heightInMeters);
    setBmi(parseFloat(computedBmi.toFixed(1)));

    // BMI Category
    if (computedBmi < 18.5) {
      setBmiCategory('Zayıf');
      setBmiColor('text-blue-500 bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/50');
    } else if (computedBmi >= 18.5 && computedBmi < 25) {
      setBmiCategory('Normal (Sağlıklı)');
      setBmiColor('text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/50');
    } else if (computedBmi >= 25 && computedBmi < 30) {
      setBmiCategory('Fazla Kilolu');
      setBmiColor('text-amber-500 bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/50');
    } else {
      setBmiCategory('Obez');
      setBmiColor('text-rose-500 bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/50');
    }

    // Ideal Weight Range
    const minIdeal = 18.5 * (heightInMeters * heightInMeters);
    const maxIdeal = 24.9 * (heightInMeters * heightInMeters);
    setIdealWeightRange({
      min: Math.round(minIdeal),
      max: Math.round(maxIdeal),
    });

    // BMR (Mifflin-St Jeor)
    let computedBmr = 0;
    if (gender === 'male') {
      computedBmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      computedBmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }
    setBmr(Math.round(computedBmr));

    // TDEE Multipliers
    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9,
    };
    const computedTdee = computedBmr * activityMultipliers[activity];
    setTdee(Math.round(computedTdee));

    // Target Calories based on Goal
    let computedTarget = computedTdee;
    if (goal === 'lose') {
      computedTarget = computedTdee - 500;
      if (computedTarget < computedBmr * 1.1) {
        computedTarget = Math.round(computedBmr * 1.1); // Keep above survival level
      }
    } else if (goal === 'gain') {
      computedTarget = computedTdee + 500;
    }
    setTargetCalories(Math.round(computedTarget));
  }, [weight, height, age, gender, activity, goal]);

  const handleApplyToProfile = () => {
    onUpdateProfile({
      weight,
      height,
      age,
      gender,
      activityLevel: activity,
      weightGoal: goal,
      dailyCalorieTarget: targetCalories,
    });
    alert('Hesaplanan değerler profilinize ve günlük hedeflerinize başarıyla uygulandı!');
  };

  return (
    <div className="space-y-6" id="bmi-calorie-section">
      {/* Title & Introduction */}
      <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
          <Calculator className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
            VKİ ve Kalori Hesaplayıcı
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
            Vücut kitle indeksinizi ve günlük enerji harcamanızı hesaplayın
          </p>
        </div>
      </div>

      {/* Calculator Form & Output Container */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 space-y-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans mb-2 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-emerald-500" /> Vücut Ölçüleriniz
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                Kilo (kg)
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                Boy (cm)
              </label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                Yaş
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                Cinsiyet
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
              >
                <option value="male">Erkek</option>
                <option value="female">Kadın</option>
                <option value="other">Diğer</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
              Fiziksel Aktivite Düzeyi
            </label>
            <select
              value={activity}
              onChange={(e) => setActivity(e.target.value as any)}
              className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
            >
              <option value="sedentary">Hareketsiz (Ofis çalışanı, egzersizsiz)</option>
              <option value="light">Az Aktif (Haftada 1-3 gün hafif spor)</option>
              <option value="moderate">Orta Aktif (Haftada 3-5 gün orta egzersiz)</option>
              <option value="active">Çok Aktif (Haftada 6-7 gün ağır spor)</option>
              <option value="very_active">Ekstra Aktif (Atletik / Ağır iş & her gün çift idman)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
              Kilo Hedefi
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'lose', label: 'Kilo Verme' },
                { id: 'maintain', label: 'Koruma' },
                { id: 'gain', label: 'Kilo Alma' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setGoal(item.id as any)}
                  className={`py-2 px-1 text-xs font-medium rounded-xl border transition-all ${
                    goal === item.id
                      ? 'bg-emerald-500 text-white border-emerald-500 shadow-sm'
                      : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleApplyToProfile}
            className="w-full mt-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold py-2.5 px-4 rounded-xl shadow-md shadow-emerald-500/10 hover:shadow-emerald-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" /> Verileri Profilime Kaydet
          </button>
        </div>

        {/* Outputs Column */}
        <div className="space-y-5">
          {/* BMI Result Card */}
          <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-emerald-500" /> Vücut Kitle İndeksi (VKİ)
            </h3>

            <div className="flex items-baseline space-x-3">
              <span className="text-4xl font-extrabold text-gray-900 dark:text-gray-100 font-mono tracking-tight">
                {bmi}
              </span>
              <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${bmiColor}`}>
                {bmiCategory}
              </span>
            </div>

            {/* Simple Graphic Gauge */}
            <div className="relative pt-1">
              <div className="overflow-hidden h-2.5 text-xs flex rounded-full bg-gray-100 dark:bg-gray-800">
                {/* Zayıf */}
                <div style={{ width: '18.5%' }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-400"></div>
                {/* Normal */}
                <div style={{ width: '25%' }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-emerald-400"></div>
                {/* Kilolu */}
                <div style={{ width: '25%' }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-amber-400"></div>
                {/* Obez */}
                <div style={{ width: '31.5%' }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-rose-400"></div>
              </div>

              {/* Slider cursor indicating current BMI */}
              <div
                className="absolute top-[-4px] transition-all duration-300"
                style={{
                  left: `${Math.min(95, Math.max(2, ((bmi - 14) / 26) * 100))}%`,
                }}
              >
                <div className="w-3.5 h-3.5 bg-emerald-600 border-2 border-white dark:border-gray-900 rounded-full shadow-md"></div>
              </div>

              {/* Gauge labels */}
              <div className="flex justify-between text-[10px] text-gray-400 font-mono mt-1 px-1">
                <span>15.0</span>
                <span>18.5 (Normal)</span>
                <span>25.0</span>
                <span>30.0 (Obez)</span>
                <span>40.0</span>
              </div>
            </div>

            <div className="bg-gray-50 dark:bg-gray-850 rounded-xl p-3 text-xs text-gray-600 dark:text-gray-400 space-y-1">
              <div className="flex justify-between">
                <span>Boyunuz için ideal kilo aralığı:</span>
                <span className="font-semibold text-gray-800 dark:text-gray-200 font-mono">
                  {idealWeightRange.min} - {idealWeightRange.max} kg
                </span>
              </div>
              <p className="text-[11px] text-gray-500 leading-relaxed pt-1 flex items-start gap-1">
                <Info className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                VKİ değerinizin 18.5 ile 24.9 arasında olması sağlıklı bir ağırlığı temsil eder.
              </p>
            </div>
          </div>

          {/* Calories Result Card */}
          <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-emerald-500" /> Günlük Kalori Hesabı
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/10 rounded-xl p-3.5">
                <p className="text-2xs text-gray-500 dark:text-gray-400 font-semibold uppercase tracking-wider">
                  Bazal Metabolizma (BMH)
                </p>
                <p className="text-xl font-bold text-gray-800 dark:text-gray-200 font-mono tracking-tight mt-0.5">
                  {bmr} <span className="text-xs font-normal text-gray-400">kcal</span>
                </p>
                <p className="text-[10px] text-gray-400 dark:text-gray-500 leading-tight mt-1">
                  Dinlenme halinde yaktığınız kalori miktarı.
                </p>
              </div>

              <div className="bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/10 rounded-xl p-3.5">
                <p className="text-2xs text-gray-500 dark:text-gray-400 font-semibold uppercase tracking-wider">
                  Günlük Harcama (TDEE)
                </p>
                <p className="text-xl font-bold text-gray-800 dark:text-gray-200 font-mono tracking-tight mt-0.5">
                  {tdee} <span className="text-xs font-normal text-gray-400">kcal</span>
                </p>
                <p className="text-[10px] text-gray-400 dark:text-gray-500 leading-tight mt-1">
                  Aktiviteniz dahil toplam harcanan kalori.
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-xl p-4 shadow-sm relative overflow-hidden">
              {/* Abs decoration circles */}
              <div className="absolute top-[-20%] right-[-10%] w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
              
              <p className="text-2xs font-semibold uppercase tracking-widest text-emerald-100">
                Hedef Günlük Kalori İhtiyacınız
              </p>
              <div className="flex items-baseline space-x-1.5 mt-1">
                <span className="text-3xl font-extrabold font-mono tracking-tight">{targetCalories}</span>
                <span className="text-sm font-medium text-emerald-100">kcal / gün</span>
              </div>
              <p className="text-xs text-emerald-50/90 mt-2 leading-relaxed font-sans">
                {goal === 'lose'
                  ? 'Kilo vermek için güvenli bir kalori açığı (Günde yaklaşık 500 kcal açık) uygulanmıştır.'
                  : goal === 'gain'
                  ? 'Kilo almak (kas kütlesi vb.) için kalori fazlası (Günde yaklaşık 500 kcal ek) uygulanmıştır.'
                  : 'Kilonuzu korumak için dengeli beslenme ihtiyacınız.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
