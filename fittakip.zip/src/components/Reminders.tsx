/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Reminder } from '../types';
import { Bell, BellOff, Plus, Trash2, Clock, CheckCircle2, ShieldAlert, Sparkles } from 'lucide-react';

interface RemindersProps {
  reminders: Reminder[];
  onToggleReminder: (id: string) => void;
  onAddReminder: (title: string, time: string, type: Reminder['type']) => void;
  onDeleteReminder: (id: string) => void;
}

export default function Reminders({
  reminders,
  onToggleReminder,
  onAddReminder,
  onDeleteReminder,
}: RemindersProps) {
  const [newTitle, setNewTitle] = useState<string>('');
  const [newTime, setNewTime] = useState<string>('09:00');
  const [newType, setNewType] = useState<Reminder['type']>('water');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTitle.trim()) {
      onAddReminder(newTitle.trim(), newTime, newType);
      setNewTitle('');
    } else {
      // Default titles based on type if empty
      let title = 'Hatırlatıcı';
      if (newType === 'water') title = 'Su İçme Zamanı 💧';
      if (newType === 'stretch') title = 'Esneklik ve Duruş Egzersizi 🤸‍♂️';
      if (newType === 'sleep') title = 'Uyku Hazırlığı 🌙';
      onAddReminder(title, newTime, newType);
    }
  };

  const getEmojiForType = (type: Reminder['type']) => {
    switch (type) {
      case 'water': return '💧';
      case 'stretch': return '🤸‍♂️';
      case 'sleep': return '🌙';
      default: return '🔔';
    }
  };

  return (
    <div className="space-y-6" id="reminders-panel">
      {/* Title block */}
      <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
          <Bell className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
            Akıllı Hatırlatıcılar
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
            Sağlıklı yaşam alışkanlıklarınızı düzenli bildirimlerle destekleyin
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ADD REMINDER FORM */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-emerald-500" /> Yeni Hatırlatıcı Kur
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Etkinlik Türü</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'water', label: 'Su İç' },
                  { id: 'stretch', label: 'Egzersiz/Açma' },
                  { id: 'sleep', label: 'Uyku' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setNewType(item.id as any)}
                    className={`py-2 px-1 text-[10px] font-semibold rounded-xl border transition-all ${
                      newType === item.id
                        ? 'bg-emerald-500 text-white border-emerald-500'
                        : 'bg-white dark:bg-gray-800 border-gray-150 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Özel Başlık (Opsiyonel)</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Örn: 1 Bardak Su İç, Yürüyüş Yap"
                className="w-full px-3 py-2 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Alarm Saati</label>
              <input
                type="time"
                required
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                className="w-full px-3 py-2 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 px-4 rounded-xl shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Alarmı Kur
            </button>
          </form>

          {/* Quick tips */}
          <div className="bg-amber-50/50 dark:bg-amber-950/10 border border-amber-100/20 dark:border-amber-900/10 rounded-xl p-3.5 flex items-start gap-2 text-2xs text-amber-800 dark:text-amber-400">
            <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <span className="leading-relaxed">
              <strong>Mobil Simülasyon:</strong> Hatırlatıcılar tarayıcıda sanal olarak çalışmaktadır. Alarm zamanı geldiğinde uygulama içinde anlık görsel uyarılar tetiklenir.
            </span>
          </div>
        </div>

        {/* ACTIVE REMINDERS LIST */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-emerald-500" /> Aktif Alarmlar ({reminders.length})
          </h3>

          {reminders.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center border-2 border-dashed border-gray-150 dark:border-gray-850 rounded-2xl text-center p-4">
              <BellOff className="w-8 h-8 text-gray-300 mb-2" />
              <p className="text-2xs text-gray-400 italic font-sans">Kurulu hatırlatıcı bulunmuyor.</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
              {reminders.map((reminder) => (
                <div
                  key={reminder.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                    reminder.active
                      ? 'bg-emerald-50/20 dark:bg-emerald-950/10 border-emerald-100/50 dark:border-emerald-900/40'
                      : 'bg-gray-50/40 dark:bg-gray-850/40 border-gray-100 dark:border-gray-800 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl" role="img" aria-label="type">
                      {getEmojiForType(reminder.type)}
                    </span>
                    <div className="space-y-0.5">
                      <p className="text-xs font-bold text-gray-800 dark:text-gray-200 leading-normal">
                        {reminder.title}
                      </p>
                      <p className="text-[10px] font-bold font-mono text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {reminder.time}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Toggle Switch */}
                    <button
                      onClick={() => onToggleReminder(reminder.id)}
                      className={`w-9 h-5 rounded-full p-0.5 transition-all relative ${
                        reminder.active ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-700'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${
                          reminder.active ? 'translate-x-4' : 'translate-x-0'
                        }`}
                      ></div>
                    </button>

                    <button
                      onClick={() => onDeleteReminder(reminder.id)}
                      className="text-gray-400 hover:text-rose-500 p-1"
                      title="Sıfırla / Sil"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
