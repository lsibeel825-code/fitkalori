/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UserProfile, WaterLog, StepLog, WeightLog, SleepLog, DietPlan } from '../types';
import {
  Heart,
  Flame,
  Droplet,
  Footprints,
  Scale,
  Moon,
  ChevronRight,
  Trophy,
  Activity,
  Award,
  TrendingDown,
  TrendingUp,
  Apple,
} from 'lucide-react';

interface DashboardProps {
  profile: UserProfile;
  waterLogs: WaterLog[];
  stepLogs: StepLog[];
  weightLogs: WeightLog[];
  sleepLogs: SleepLog[];
  activeDietPlan: DietPlan | undefined;
  onNavigateToTab: (tab: string) => void;
  onQuickAddWater: (amount: number) => void;
  onQuickAddSteps: (amount: number) => void;
}

export default function Dashboard({
  profile,
  waterLogs,
  stepLogs,
  weightLogs,
  sleepLogs,
  activeDietPlan,
  onNavigateToTab,
  onQuickAddWater,
  onQuickAddSteps,
}: DashboardProps) {
  // Get today's logs
  const todayStr = new Date().toISOString().split('T')[0];

  const todayWater = waterLogs.reduce((acc, log) => acc + log.amount, 0);
  const waterTarget = profile.dailyWaterTarget || 2000;
  const waterPercent = Math.min(100, Math.round((todayWater / waterTarget) * 100));

  const todayStepsLog = stepLogs.find((l) => l.date === todayStr);
  const todaySteps = todayStepsLog ? todayStepsLog.steps : 0;
  const stepTarget = profile.dailyStepTarget || 8000;
  const stepPercent = Math.min(100, Math.round((todaySteps / stepTarget) * 100));

  const currentWeight = weightLogs.length > 0 ? weightLogs[weightLogs.length - 1].weight : profile.weight || 70;
  const startWeight = weightLogs.length > 0 ? weightLogs[0].weight : profile.weight || 70;
  const targetWeight = profile.weightGoal === 'lose' ? Math.round(startWeight * 0.9) : profile.weightGoal === 'gain' ? Math.round(startWeight * 1.1) : startWeight;

  const todaySleepLog = sleepLogs.find((l) => l.date === todayStr);
  const todaySleep = todaySleepLog ? todaySleepLog.duration : 0;
  const sleepTarget = profile.dailySleepTarget || 8;
  const sleepPercent = Math.min(100, Math.round((todaySleep / sleepTarget) * 100));

  // Calories
  const stepsCalories = Math.round(todaySteps * 0.04);
  const calorieTarget = profile.dailyCalorieTarget || 2000;

  // Compute a dynamic wellness score (0 - 100)
  // Water weight 25%, Steps weight 35%, Sleep weight 25%, Weight tracker presence 15%
  const scoreWater = waterPercent * 0.25;
  const scoreSteps = stepPercent * 0.35;
  const scoreSleep = sleepPercent * 0.25;
  const scoreWeight = (weightLogs.length > 0 ? 100 : 0) * 0.15;
  const wellnessScore = Math.round(scoreWater + scoreSteps + scoreSleep + scoreWeight);

  // Wellness score feedback text
  const getWellnessFeedback = (score: number) => {
    if (score >= 90) return { title: 'Harika gidiyorsun! 🌟', desc: 'Bütün günlük sağlık hedeflerine yaklaştın veya ulaştın. Vücudun sana teşekkür ediyor!', color: 'text-emerald-500' };
    if (score >= 60) return { title: 'Güzel İlerleme! 👍', desc: 'Bugün harika adımlar attın. Su içmeyi ve biraz daha yürümeyi ihmal etme.', color: 'text-emerald-600 dark:text-emerald-400' };
    if (score >= 30) return { title: 'Yavaş Başlangıç 🏃', desc: 'Günü yarıladık sayılır! Şimdi ayağa kalkıp su içmek ve 1000 adım atmak için harika bir an.', color: 'text-amber-500' };
    return { title: 'Harekete Geç! ⚡', desc: 'Hala vaktin var! Sağlık skorunu yükseltmek için ilk bardağını iç ve birkaç adım at.', color: 'text-rose-500' };
  };

  const feedback = getWellnessFeedback(wellnessScore);

  return (
    <div className="space-y-6 animate-fade-in" id="dashboard-tab">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-br from-emerald-550 to-teal-650 dark:from-emerald-850 dark:to-teal-950 rounded-3xl p-5 text-white relative overflow-hidden shadow-md shadow-emerald-500/10">
        <div className="absolute right-[-5%] top-[-20%] w-36 h-36 bg-white/5 rounded-full blur-2xl"></div>
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold font-mono tracking-wider bg-white/10 px-2.5 py-0.5 rounded-full uppercase">
              Bugünkü Raporunuz
            </span>
            <h1 className="text-2xl font-bold font-sans tracking-tight pt-1">
              Merhaba, FitTakipçim!
            </h1>
            <p className="text-xs text-emerald-100/90 font-sans leading-relaxed max-w-md">
              Bugün sağlıklı alışkanlıklarını sürdürmek ve hedeflerine ulaşmak için harika bir gün. Hadi değerleri güncelleyelim!
            </p>
          </div>

          {/* Wellness Score Circular Indicator */}
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-2xl p-3 shrink-0 border border-white/10">
            <div className="relative w-16 h-16 flex items-center justify-center bg-emerald-950/20 rounded-full">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="32" cy="32" r="26" className="stroke-white/10" strokeWidth="4.5" fill="transparent" />
                <circle
                  cx="32"
                  cy="32"
                  r="26"
                  className="stroke-emerald-300 transition-all duration-700"
                  strokeWidth="4.5"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 26}`}
                  strokeDashoffset={`${2 * Math.PI * 26 * (1 - wellnessScore / 100)}`}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute text-sm font-extrabold font-mono">{wellnessScore}</span>
            </div>
            <div>
              <p className="text-[10px] font-bold text-emerald-100/80 uppercase">Sağlık Skoru</p>
              <p className="text-xs font-bold leading-normal text-emerald-50">{feedback.title}</p>
            </div>
          </div>
        </div>

        {/* Motivational Tip Bar */}
        <div className="mt-4 pt-4 border-t border-white/10 text-2xs text-emerald-100/95 font-sans leading-relaxed">
          {feedback.desc}
        </div>
      </div>

      {/* Grid of trackers widgets */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Step Widget */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 shadow-sm relative flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-500 rounded-xl">
              <Footprints className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-mono font-bold text-gray-400">%{stepPercent}</span>
          </div>
          <div className="mt-4">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Adım Sayar</p>
            <p className="text-lg font-extrabold text-gray-800 dark:text-gray-100 font-mono mt-0.5">
              {todaySteps.toLocaleString('tr-TR')}
            </p>
            {/* Minimal Progress Bar */}
            <div className="w-full bg-gray-100 dark:bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${stepPercent}%` }}></div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-50 dark:border-gray-800 flex justify-between items-center">
            <span className="text-[10px] text-gray-400 font-mono">{stepsCalories} kcal</span>
            <button
              onClick={() => onQuickAddSteps(1000)}
              className="text-2xs font-bold text-emerald-500 hover:text-emerald-600 flex items-center"
            >
              +1K Adım
            </button>
          </div>
        </div>

        {/* Water Widget */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 shadow-sm relative flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start">
            <div className="p-2 bg-sky-50 dark:bg-sky-950/30 text-sky-500 rounded-xl">
              <Droplet className="w-5 h-5 animate-pulse" />
            </div>
            <span className="text-[10px] font-mono font-bold text-gray-400">%{waterPercent}</span>
          </div>
          <div className="mt-4">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Su Takibi</p>
            <p className="text-lg font-extrabold text-gray-800 dark:text-gray-100 font-mono mt-0.5">
              {todayWater} <span className="text-[11px] font-normal text-gray-400">ml</span>
            </p>
            {/* Minimal Progress Bar */}
            <div className="w-full bg-gray-100 dark:bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-sky-500 h-full rounded-full transition-all duration-500" style={{ width: `${waterPercent}%` }}></div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-50 dark:border-gray-800 flex justify-between items-center">
            <span className="text-[10px] text-gray-400 font-sans">Hedef: {waterTarget}</span>
            <button
              onClick={() => onQuickAddWater(250)}
              className="text-2xs font-bold text-sky-500 hover:text-sky-600 flex items-center"
            >
              +250ml Su
            </button>
          </div>
        </div>

        {/* Weight Widget */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 shadow-sm relative flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start">
            <div className="p-2 bg-amber-50 dark:bg-amber-950/30 text-amber-500 rounded-xl">
              <Scale className="w-5 h-5" />
            </div>
            <span className="text-3xs font-bold text-gray-400 flex items-center gap-0.5">
              Hedef: {targetWeight} kg
            </span>
          </div>
          <div className="mt-4">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Kilo Takibi</p>
            <p className="text-lg font-extrabold text-gray-800 dark:text-gray-100 font-mono mt-0.5">
              {currentWeight} <span className="text-[11px] font-normal text-gray-400">kg</span>
            </p>
            {/* Status indicators */}
            <p className="text-[10px] text-gray-400 mt-1.5 flex items-center gap-1 leading-none font-sans">
              <Activity className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Başlangıçtan beri değişim:</span>
            </p>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-50 dark:border-gray-800 flex justify-between items-center">
            <span className="text-2xs font-bold font-mono text-gray-700 dark:text-gray-300">
              {currentWeight - startWeight > 0 ? `+${(currentWeight - startWeight).toFixed(1)}` : (currentWeight - startWeight).toFixed(1)} kg
            </span>
            <button
              onClick={() => onNavigateToTab('trackers')}
              className="text-2xs font-bold text-amber-500 hover:text-amber-600 flex items-center"
            >
              Kayıtlar <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>

        {/* Sleep Widget */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 shadow-sm relative flex flex-col justify-between hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/30 text-indigo-500 rounded-xl">
              <Moon className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-mono font-bold text-gray-400">%{sleepPercent}</span>
          </div>
          <div className="mt-4">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Gece Uykusu</p>
            <p className="text-lg font-extrabold text-gray-800 dark:text-gray-100 font-mono mt-0.5">
              {todaySleep} <span className="text-[11px] font-normal text-gray-400">saat</span>
            </p>
            {/* Minimal Progress Bar */}
            <div className="w-full bg-gray-100 dark:bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-indigo-500 h-full rounded-full transition-all duration-500" style={{ width: `${sleepPercent}%` }}></div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-50 dark:border-gray-800 flex justify-between items-center">
            <span className="text-2xs text-gray-400 font-sans">Hedef: {sleepTarget}saat</span>
            <button
              onClick={() => onNavigateToTab('trackers')}
              className="text-2xs font-bold text-indigo-500 hover:text-indigo-600 flex items-center"
            >
              Güncelle <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Row 2: Diet Plan and Motivations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Active Diet Plan Panel */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
              <Apple className="w-4 h-4 text-emerald-500" /> Aktif Diyet Planınız
            </h3>
            <button
              onClick={() => onNavigateToTab('diet')}
              className="text-2xs font-bold text-emerald-500 hover:text-emerald-600 flex items-center"
            >
              Diyetleri Yönet <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
            </button>
          </div>

          {activeDietPlan ? (
            <div className="space-y-3 bg-emerald-50/20 dark:bg-emerald-950/10 p-3.5 rounded-xl border border-emerald-100/30 dark:border-emerald-900/30">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                  {activeDietPlan.title}
                </span>
                <span className="text-[9px] font-extrabold uppercase bg-emerald-500 text-white px-2 py-0.5 rounded-full">
                  AKTİF
                </span>
              </div>
              <p className="text-2xs text-gray-500 dark:text-gray-400 leading-relaxed line-clamp-2">
                {activeDietPlan.description}
              </p>
              <div className="text-2xs text-gray-400 border-t border-emerald-100/30 dark:border-emerald-900/30 pt-2 flex justify-between">
                <span>Öğün Sayısı: <strong>{activeDietPlan.meals.length} adet</strong></span>
                <span>Toplam Yaklaşık Kalori: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{activeDietPlan.meals.reduce((sum, m) => sum + m.calories, 0)} kcal</strong></span>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center bg-gray-50 dark:bg-gray-850 rounded-xl border border-gray-100 dark:border-gray-800">
              <Apple className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <p className="text-2xs font-bold text-gray-600 dark:text-gray-450">Aktif Beslenme Programı Yok</p>
              <p className="text-3xs text-gray-400 max-w-xs mx-auto mt-1">
                Yapay zeka asistanı veya hazır diyet planları ile beslenme düzeninizi planlayabilirsiniz.
              </p>
              <button
                onClick={() => onNavigateToTab('diet')}
                className="mt-3.5 text-3xs font-extrabold bg-emerald-500 text-white py-1.5 px-3 rounded-lg hover:bg-emerald-600 transition-colors"
              >
                Plan Seç / AI Oluştur
              </button>
            </div>
          )}
        </div>

        {/* Dynamic Achievements & Reminders status */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
            <Award className="w-4 h-4 text-emerald-500" /> Bugün Kazandığınız Rozetler
          </h3>

          <div className="grid grid-cols-3 gap-2">
            <div
              className={`p-3 rounded-xl border text-center flex flex-col items-center justify-center space-y-1 transition-all ${
                waterPercent >= 100
                  ? 'bg-sky-50/50 dark:bg-sky-950/15 border-sky-300/40 text-sky-700 dark:text-sky-400 opacity-100'
                  : 'bg-gray-50/50 dark:bg-gray-850 border-gray-100 dark:border-gray-800 opacity-40'
              }`}
            >
              <span className="text-xl">💧</span>
              <p className="text-3xs font-extrabold font-sans leading-none">Su Kahramanı</p>
              <p className="text-[8px] text-gray-400">Hedef su</p>
            </div>

            <div
              className={`p-3 rounded-xl border text-center flex flex-col items-center justify-center space-y-1 transition-all ${
                stepPercent >= 100
                  ? 'bg-emerald-50/50 dark:bg-emerald-950/15 border-emerald-300/40 text-emerald-700 dark:text-emerald-400 opacity-100'
                  : 'bg-gray-50/50 dark:bg-gray-850 border-gray-100 dark:border-gray-800 opacity-40'
              }`}
            >
              <span className="text-xl">👟</span>
              <p className="text-3xs font-extrabold font-sans leading-none">Aktif Atlet</p>
              <p className="text-[8px] text-gray-400">Hedef adım</p>
            </div>

            <div
              className={`p-3 rounded-xl border text-center flex flex-col items-center justify-center space-y-1 transition-all ${
                sleepPercent >= 100
                  ? 'bg-indigo-50/50 dark:bg-indigo-950/15 border-indigo-300/40 text-indigo-700 dark:text-indigo-400 opacity-100'
                  : 'bg-gray-50/50 dark:bg-gray-850 border-gray-100 dark:border-gray-800 opacity-40'
              }`}
            >
              <span className="text-xl">💤</span>
              <p className="text-3xs font-extrabold font-sans leading-none">Derin Uyku</p>
              <p className="text-[8px] text-gray-400">Hedef uyku</p>
            </div>
          </div>

          <div className="pt-2 border-t border-gray-100 dark:border-gray-800 text-3xs text-gray-400 leading-normal flex items-start gap-1">
            <Trophy className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>Her gün hedeflerinizi tamamlayarak sağlıklı bir rutine sahip olun. Sağlık skorunuz rozetlerle birlikte artar!</span>
          </div>
        </div>
      </div>
    </div>
  );
}
