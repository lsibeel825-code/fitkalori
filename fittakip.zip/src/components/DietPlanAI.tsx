/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserProfile, DietPlan, Meal } from '../types';
import { ChefHat, Sparkles, BookOpen, Utensils, Apple, Check, AlertCircle, Loader2, RefreshCw } from 'lucide-react';

interface DietPlanAIProps {
  profile: UserProfile;
  savedDietPlans: DietPlan[];
  activeDietPlanId: string | null;
  onSelectActiveDietPlan: (id: string | null) => void;
  onSaveNewDietPlan: (plan: DietPlan) => void;
  onDeleteDietPlan: (id: string) => void;
}

const PRESET_DIETS: DietPlan[] = [
  {
    id: 'preset-akdeniz',
    title: 'Akdeniz Diyeti (Dengeli Yaşam)',
    type: 'preset',
    description: 'Sağlıklı yağlar, bol sebze, balık ve tam tahıllar içeren, kalp sağlığını destekleyen dünyaca ünlü dengeli beslenme modeli.',
    meals: [
      { name: 'Kahvaltı (08:30)', food: '2 adet haşlanmış yumurta, 1 dilim süzme peynir, bol maydanoz-salatalık, 5-6 adet zeytin, 1 dilim tam buğday ekmeği', calories: 340 },
      { name: 'Öğle Yemeği (13:00)', food: 'Zeytinyağlı taze fasulye (1 porsiyon), 1 kase süzme yoğurt, mevsim salatası (limonlu ve sızma zeytinyağlı)', calories: 420 },
      { name: 'Ara Öğün (16:00)', food: '1 avuç çiğ badem veya ceviz, 1 adet yeşil elma', calories: 180 },
      { name: 'Akşam Yemeği (19:30)', food: 'Izgara levrek veya çipura (150g), buharda pişmiş limonlu brokoli ve karnabahar, mor lahana salatası', calories: 450 },
    ],
    tips: [
      'Günde en az 2 litre su tüketin.',
      'Yemeklerinizi hazırlarken tereyağı yerine sızma zeytinyağı tercih edin.',
      'Tuz miktarını azaltıp baharat ve limonla lezzet katın.',
    ],
  },
  {
    id: 'preset-aralikli-oruc',
    title: 'Aralıklı Oruç (16:8 Metodu)',
    type: 'preset',
    description: 'Hücresel yenilenmeyi ve yağ yakımını hızlandırmak için günde 16 saat açlık, 8 saatlik beslenme penceresi içeren popüler beslenme planı.',
    meals: [
      { name: 'İlk Öğün - Açılış (12:00)', food: 'Yulaflı omlet (2 yumurta, 3 kaşık yulaf ezmesi), çeri domatesler, beyaz peynir, avokado dilimleri, yeşil çay', calories: 480 },
      { name: 'Ara Öğün (15:30)', food: '1 kase yoğurt içerisine 1 tatlı kaşığı chia tohumu ve yarım muz', calories: 190 },
      { name: 'Son Öğün - Kapanış (19:30)', food: 'Izgara tavuk göğsü (150g), 4-5 kaşık karabuğday veya siyez bulguru pilavı, bol yeşil salata', calories: 520 },
    ],
    tips: [
      '12:00 öncesi ve 20:00 sonrası kalorisiz içecekler (su, şekersiz filtre kahve, maden suyu, bitki çayları) serbesttir.',
      'Beslenme penceresinde aşırı yememeye, besleyici gıdalar almaya özen gösterin.',
    ],
  },
  {
    id: 'preset-protein',
    title: 'Kas Kazanımı (Yüksek Protein)',
    type: 'preset',
    description: 'Kas kütlesini korumak, onarmak ve geliştirmek isteyen sporcular veya aktif bireyler için tasarlanmış yüksek amino asit içerikli diyet.',
    meals: [
      { name: 'Kahvaltı', food: '3 yumurta beyazı, 1 tam yumurta ile yapılmış lorlu omlet, 50g yulaf ezmesi (sütle pişirilmiş), 1 muz', calories: 550 },
      { name: 'Öğle Yemeği', food: 'Fırınlanmış hindi göğsü (180g), 1 su bardağı haşlanmış basmati pirinç, fırın patates dilimleri, yağsız cacık', calories: 650 },
      { name: 'Spor Sonrası / Ara Öğün', food: '1 ölçek whey protein tozu (su ile) veya 150g süzme lor peyniri, 10 adet çiğ fındık', calories: 220 },
      { name: 'Akşam Yemeği', food: 'Yağsız dana bonfile veya kıyma (150g), haşlanmış kinoa, fırın sebze tepsisi (kabak, patlıcan, biber)', calories: 580 },
    ],
    tips: [
      'Ağır antrenman günlerinde karbonhidrat miktarını hafifçe artırabilirsiniz.',
      'Kas onarımı için her öğünde en az 25-30g kaliteli protein almaya dikkat edin.',
    ],
  },
];

export default function DietPlanAI({
  profile,
  savedDietPlans,
  activeDietPlanId,
  onSelectActiveDietPlan,
  onSaveNewDietPlan,
  onDeleteDietPlan,
}: DietPlanAIProps) {
  const [dietPref, setDietPref] = useState<string>('all');
  const [allergies, setAllergies] = useState<string>('');
  const [dislikedFoods, setDislikedFoods] = useState<string>('');
  const [generating, setGenerating] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleGenerateAIDiet = async () => {
    setGenerating(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/diet-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile,
          preference: dietPref,
          allergies,
          dislikedFoods,
        }),
      });

      if (!response.ok) {
        throw new Error('Yapay zeka planı oluştururken sunucu hatası oluştu.');
      }

      const data = await response.json();
      if (data.success && data.plan) {
        // Save new plan
        const newPlan: DietPlan = {
          id: `ai-${Date.now()}`,
          title: `Kişiselleştirilmiş AI Planı (${dietPref === 'all' ? 'Genel' : dietPref.toUpperCase()})`,
          type: 'ai',
          description: data.plan.description || 'Yapay zeka tarafından hazırlanan özel beslenme planınız.',
          meals: data.plan.meals || [],
          tips: data.plan.tips || [],
        };
        onSaveNewDietPlan(newPlan);
        onSelectActiveDietPlan(newPlan.id);
      } else {
        throw new Error(data.error || 'Geçersiz veri formatı alındı.');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Diyet planı oluşturulurken beklenmeyen bir hata meydana geldi. Lütfen tekrar deneyin.');
    } finally {
      setGenerating(false);
    }
  };

  const getActivePlan = (): DietPlan | undefined => {
    if (!activeDietPlanId) return undefined;
    // Check presets
    const preset = PRESET_DIETS.find((d) => d.id === activeDietPlanId);
    if (preset) return preset;
    // Check saved/generated
    return savedDietPlans.find((d) => d.id === activeDietPlanId);
  };

  const activePlan = getActivePlan();

  return (
    <div className="space-y-6" id="diet-plan-container">
      {/* Title */}
      <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
          <ChefHat className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
            Akıllı Diyet Planlayıcı
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
            Hazır programları uygulayın veya yapay zeka ile kişiye özel plan oluşturun
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Presets and Generator Inputs */}
        <div className="lg:col-span-1 space-y-5">
          {/* Presets List */}
          <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-emerald-500" /> Standart Diyetler
            </h3>
            <div className="space-y-2">
              {PRESET_DIETS.map((diet) => {
                const isActive = activeDietPlanId === diet.id;
                return (
                  <button
                    key={diet.id}
                    onClick={() => onSelectActiveDietPlan(diet.id)}
                    className={`w-full text-left p-3 rounded-xl border text-xs font-medium transition-all flex items-start justify-between ${
                      isActive
                        ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-900 dark:text-emerald-300 shadow-sm'
                        : 'bg-white dark:bg-gray-800 border-gray-150 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                    }`}
                  >
                    <div className="space-y-1">
                      <p className="font-bold">{diet.title}</p>
                      <p className="text-[10px] text-gray-400 line-clamp-1 font-sans">{diet.description}</p>
                    </div>
                    {isActive && <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5 ml-2" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* AI Generator Panel */}
          <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" /> Yapay Zeka Diyet Asistanı
            </h3>
            <p className="text-[11px] text-gray-500 dark:text-gray-400 leading-relaxed font-sans">
              Yaş, boy, kilo, günlük kalori hedefiniz (<strong>{profile.dailyCalorieTarget || 2000} kcal</strong>) ve hedeflerinize göre tamamen size özel bir beslenme planı hazırlar.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Diyet Tercihi</label>
                <select
                  value={dietPref}
                  onChange={(e) => setDietPref(e.target.value)}
                  className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">Fark Etmez (Her şey dahil)</option>
                  <option value="vegetarian">Vejetaryen (Et/Balık hariç)</option>
                  <option value="vegan">Vegan (Tüm hayvansal gıdalar hariç)</option>
                  <option value="gluten-free">Glutensiz</option>
                  <option value="keto">Keto (Düşük Karbonhidrat, Yüksek Yağ)</option>
                  <option value="low-fat">Düşük Yağlı</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Alerjileriniz</label>
                <input
                  type="text"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                  placeholder="Çilek, Yer fıstığı, Gluten, vb."
                  className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[10px] text-gray-400 mb-1 font-semibold uppercase">Tüketmediğiniz Gıdalar</label>
                <input
                  type="text"
                  value={dislikedFoods}
                  onChange={(e) => setDislikedFoods(e.target.value)}
                  placeholder="Kereviz, Patlıcan, Brokoli vb."
                  className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <button
                type="button"
                onClick={handleGenerateAIDiet}
                disabled={generating}
                className="w-full mt-2 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 disabled:from-emerald-400 disabled:to-emerald-500 text-white text-xs font-bold py-2.5 px-4 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Hazırlanıyor...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" /> AI Diyet Planı Oluştur
                  </>
                )}
              </button>
            </div>

            {/* Error messaging */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/50 rounded-xl text-2xs text-rose-600 dark:text-rose-400 flex items-start gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          {/* AI Generated List */}
          {savedDietPlans.length > 0 && (
            <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                <ChefHat className="w-4 h-4 text-emerald-500" /> Önceki AI Planlarınız
              </h3>
              <div className="space-y-1.5">
                {savedDietPlans.map((plan) => {
                  const isActive = activeDietPlanId === plan.id;
                  return (
                    <div
                      key={plan.id}
                      className={`flex items-center justify-between p-2 rounded-xl border text-2xs transition-all ${
                        isActive
                          ? 'bg-emerald-50/40 dark:bg-emerald-950/10 border-emerald-500/50'
                          : 'bg-gray-50/50 dark:bg-gray-850 border-gray-100 dark:border-gray-800'
                      }`}
                    >
                      <button
                        onClick={() => onSelectActiveDietPlan(plan.id)}
                        className="flex-1 text-left font-semibold text-gray-700 dark:text-gray-300 truncate mr-2"
                      >
                        {plan.title}
                      </button>
                      <button
                        onClick={() => onDeleteDietPlan(plan.id)}
                        className="text-gray-400 hover:text-rose-500 p-1"
                        title="Sil"
                      >
                        Sil
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ACTIVE DIET PLAN DETAILS */}
        <div className="lg:col-span-2 space-y-5">
          {activePlan ? (
            <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-5">
              {/* Header card details */}
              <div className="space-y-2 border-b pb-4 border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white font-sans tracking-tight">
                    {activePlan.title}
                  </h3>
                  <span
                    className={`px-2.5 py-0.5 text-3xs font-black uppercase rounded-full tracking-wider ${
                      activePlan.type === 'ai'
                        ? 'bg-amber-100 text-amber-700 border border-amber-200 dark:bg-amber-950/30 dark:text-amber-400 dark:border-amber-900/50'
                        : 'bg-emerald-100 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-900/50'
                    }`}
                  >
                    {activePlan.type === 'ai' ? 'Yapay Zeka' : 'Hazır Şablon'}
                  </span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-sans">
                  {activePlan.description}
                </p>
              </div>

              {/* Meals list */}
              <div className="space-y-4">
                <h4 className="text-2xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Utensils className="w-4 h-4 text-emerald-500" /> Günlük Öğün Listesi
                </h4>
                <div className="space-y-3">
                  {activePlan.meals.map((meal, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gray-55/40 dark:bg-gray-850/40 border border-gray-100/40 dark:border-gray-800/40 rounded-xl flex flex-col sm:flex-row justify-between sm:items-start gap-2.5 hover:shadow-sm transition-shadow"
                    >
                      <div className="space-y-1">
                        <span className="text-2xs font-bold text-emerald-600 dark:text-emerald-400 uppercase font-sans">
                          {meal.name}
                        </span>
                        <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 leading-relaxed font-sans">
                          {meal.food}
                        </p>
                      </div>
                      <div className="shrink-0 flex items-center bg-gray-100 dark:bg-gray-800 px-2.5 py-1 rounded-lg">
                        <span className="text-2xs font-bold font-mono text-gray-600 dark:text-gray-300">
                          {meal.calories} kcal
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Nutritionist tips */}
              <div className="bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100/20 dark:border-emerald-900/10 rounded-2xl p-4 space-y-2.5">
                <h4 className="text-2xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Apple className="w-4 h-4 text-emerald-500" /> Sağlıklı Beslenme İpuçları
                </h4>
                <ul className="text-2xs text-gray-600 dark:text-gray-400 space-y-1.5 pl-1.5 list-disc list-inside leading-relaxed font-sans">
                  {activePlan.tips.map((tip, idx) => (
                    <li key={idx} className="marker:text-emerald-500">
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="h-[450px] flex flex-col items-center justify-center border-2 border-dashed border-gray-150 dark:border-gray-800 rounded-3xl bg-gray-50/30 dark:bg-gray-900/30 text-center p-6">
              <ChefHat className="w-12 h-12 text-gray-300 mb-3" />
              <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300">Aktif Diyet Bulunmuyor</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 max-w-sm font-sans leading-relaxed">
                Yandaki standart diyetlerden birini seçin ya da kişisel verilerinize uygun yapay zeka programınızı hazırlatmak için sihirli butona tıklayın!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
