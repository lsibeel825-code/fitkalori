/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WeightLog, SleepLog, UserProfile } from '../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
import { Scale, Moon, Trophy, TrendingDown, TrendingUp, Sparkles, Plus, Trash2, Sliders, Check, HelpCircle } from 'lucide-react';

interface WeightAndSleepProps {
  profile: UserProfile;
  weightLogs: WeightLog[];
  sleepLogs: SleepLog[];
  onAddWeightLog: (weight: number, date: string) => void;
  onRemoveWeightLog: (id: string) => void;
  onAddSleepLog: (duration: number, quality: SleepLog['quality'], date: string) => void;
  onRemoveSleepLog: (id: string) => void;
}

export default function WeightAndSleep({
  profile,
  weightLogs,
  sleepLogs,
  onAddWeightLog,
  onRemoveWeightLog,
  onAddSleepLog,
  onRemoveSleepLog,
}: WeightAndSleepProps) {
  const [newWeight, setNewWeight] = useState<string>('');
  const [weightDate, setWeightDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const [sleepDuration, setSleepDuration] = useState<string>('8');
  const [sleepQuality, setSleepQuality] = useState<SleepLog['quality']>('good');
  const [sleepDate, setSleepDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Compute weight details
  const startWeight = weightLogs.length > 0 ? weightLogs[0].weight : profile.weight || 70;
  const currentWeight = weightLogs.length > 0 ? weightLogs[weightLogs.length - 1].weight : profile.weight || 70;
  // A hypothetical target weight based on gender and height if not set, or we can assume a standard 10% reduction or let user set it in profiles
  const targetWeight = profile.weightGoal === 'lose' ? Math.round(startWeight * 0.9) : profile.weightGoal === 'gain' ? Math.round(startWeight * 1.1) : startWeight;

  const totalDifference = parseFloat((currentWeight - startWeight).toFixed(1));
  const goalDifference = parseFloat((currentWeight - targetWeight).toFixed(1));

  // Format weight log data for Recharts
  const chartData = weightLogs.map((log) => ({
    Tarih: new Date(log.date).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short' }),
    Ağırlık: log.weight,
  }));

  const handleWeightSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const wt = parseFloat(newWeight);
    if (wt > 0 && weightDate) {
      onAddWeightLog(wt, weightDate);
      setNewWeight('');
    }
  };

  const handleSleepSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dur = parseFloat(sleepDuration);
    if (dur > 0 && sleepDate) {
      onAddSleepLog(dur, sleepQuality, sleepDate);
      setSleepDuration('8');
    }
  };

  // Compute average sleep
  const avgSleep = sleepLogs.length > 0
    ? parseFloat((sleepLogs.reduce((acc, log) => acc + log.duration, 0) / sleepLogs.length).toFixed(1))
    : 0;

  return (
    <div className="space-y-6" id="weight-sleep-container">
      {/* HEADER SECTION */}
      <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
          <Scale className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
            Kilo & Uyku Trendleri
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
            Vücut kütlenizi ve gece dinlenme kalitenizi uzun vadeli izleyin
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* WEIGHT PROGRESS MONITOR */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-5">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <Scale className="w-4.5 h-4.5 text-emerald-500" /> Kilo Takibi
            </h3>
            <span className="text-2xs font-mono font-medium text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2.5 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/50 flex items-center gap-1">
              {totalDifference < 0 ? (
                <>
                  <TrendingDown className="w-3 h-3 text-emerald-500" /> {totalDifference} kg
                </>
              ) : totalDifference > 0 ? (
                <>
                  <TrendingUp className="w-3 h-3 text-amber-500" /> +{totalDifference} kg
                </>
              ) : (
                'Stabil'
              )}
            </span>
          </div>

          {/* Quick Metrics display */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-gray-50 dark:bg-gray-850 p-2.5 rounded-xl text-center">
              <span className="text-[10px] text-gray-400 uppercase font-sans">Başlangıç</span>
              <p className="text-base font-bold font-mono text-gray-700 dark:text-gray-300 mt-0.5">
                {startWeight} <span className="text-[9px] font-normal text-gray-400">kg</span>
              </p>
            </div>
            <div className="bg-emerald-50/45 dark:bg-emerald-950/15 border border-emerald-100/30 dark:border-emerald-900/30 p-2.5 rounded-xl text-center">
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 uppercase font-sans font-bold">Güncel</span>
              <p className="text-base font-black font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
                {currentWeight} <span className="text-[9px] font-normal text-gray-400">kg</span>
              </p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-850 p-2.5 rounded-xl text-center">
              <span className="text-[10px] text-gray-400 uppercase font-sans">Hedef</span>
              <p className="text-base font-bold font-mono text-gray-700 dark:text-gray-300 mt-0.5">
                {targetWeight} <span className="text-[9px] font-normal text-gray-400">kg</span>
              </p>
            </div>
          </div>

          {/* Recharts progress chart */}
          {chartData.length > 1 ? (
            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="Tarih" tick={{ fontSize: 9 }} stroke="#9CA3AF" />
                  <YAxis type="number" domain={['dataMin - 2', 'dataMax + 2']} tick={{ fontSize: 9 }} stroke="#9CA3AF" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#111827',
                      color: '#F9FAFB',
                      fontSize: '11px',
                      borderRadius: '8px',
                      border: 'none',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="Ağırlık"
                    stroke="#10B981"
                    strokeWidth={3}
                    dot={{ r: 4, strokeWidth: 1 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-44 flex flex-col items-center justify-center border-2 border-dashed border-gray-100 dark:border-gray-800 rounded-2xl bg-gray-50/50 dark:bg-gray-900 text-center p-4">
              <Sliders className="w-8 h-8 text-gray-300 mb-2" />
              <p className="text-xs text-gray-500 font-semibold">Grafik Çizilmesi İçin Veri Bekleniyor</p>
              <p className="text-[10px] text-gray-400 mt-0.5 leading-normal max-w-[200px]">
                Trend çizgisini görüntülemek için en az iki farklı kilo kaydı eklemelisiniz.
              </p>
            </div>
          )}

          {/* Input weight form */}
          <form onSubmit={handleWeightSubmit} className="grid grid-cols-3 gap-2 pt-1 border-t border-gray-150 dark:border-gray-800">
            <div className="col-span-1">
              <input
                type="number"
                step="0.1"
                required
                value={newWeight}
                onChange={(e) => setNewWeight(e.target.value)}
                placeholder="0.0 kg"
                className="w-full px-2.5 py-1.5 text-xs border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="col-span-1">
              <input
                type="date"
                required
                value={weightDate}
                onChange={(e) => setWeightDate(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              type="submit"
              className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold py-1.5 px-3 rounded-xl shadow-sm hover:shadow-md transition-all active:scale-[0.97] flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Kaydet
            </button>
          </form>

          {/* List weights */}
          <div className="max-h-24 overflow-y-auto space-y-1.5 pr-1">
            {weightLogs.slice().reverse().map((log) => (
              <div
                key={log.id}
                className="flex justify-between items-center text-2xs p-2 bg-gray-50 dark:bg-gray-850 rounded-lg border border-gray-100/40 dark:border-gray-800/20"
              >
                <span className="font-bold text-gray-700 dark:text-gray-300 font-mono">{log.weight} kg</span>
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 font-mono">
                    {new Date(log.date).toLocaleDateString('tr-TR')}
                  </span>
                  <button
                    onClick={() => onRemoveWeightLog(log.id)}
                    className="text-gray-400 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SLEEP PROGRESS MONITOR */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-5">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <Moon className="w-4.5 h-4.5 text-indigo-500" /> Uyku Takibi
            </h3>
            <span className="text-xs font-mono font-semibold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/30 px-2 py-0.5 rounded-full border border-indigo-100 dark:border-indigo-900/50">
              Ort: {avgSleep} saat / gece
            </span>
          </div>

          {/* Display sleep metrics */}
          <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 rounded-2xl p-4 text-white relative overflow-hidden shadow-md">
            <div className="absolute right-[-10%] top-[-20%] w-20 h-20 bg-indigo-500/10 rounded-full blur-xl"></div>
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] text-indigo-200 uppercase font-sans tracking-widest font-semibold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Uyku Sağlığı Rehberi
                </span>
                <p className="text-sm font-bold mt-1 text-indigo-50">
                  {avgSleep >= 7 && avgSleep <= 9
                    ? 'Tebrikler! İdeal uyku süresini (7-9 saat) yakalıyorsunuz.'
                    : avgSleep > 0 && avgSleep < 7
                    ? 'Yetersiz uyku riski var. Hücresel yenilenme için uykuyu artırın.'
                    : avgSleep > 9
                    ? 'Gereğinden fazla uyku yorgunluk hissi yapabilir.'
                    : 'Uykunuzu takip etmeye başlamak için kayıt ekleyin.'}
                </p>
              </div>
            </div>
            {/* Sleeping status meters */}
            <div className="mt-4 flex gap-1.5">
              {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map((day, idx) => {
                // Find matching mock logs or actual logs from last 7 entries
                const lastSleepLog = sleepLogs.slice(-7)[idx];
                const heightPercent = lastSleepLog ? Math.min(100, (lastSleepLog.duration / 12) * 100) : 10;
                const isGood = lastSleepLog ? lastSleepLog.quality === 'good' : false;

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center">
                    <div className="w-full h-12 bg-indigo-950/50 rounded-md relative overflow-hidden flex flex-col justify-end">
                      <div
                        className={`w-full rounded-t-sm transition-all duration-500 ${
                          isGood ? 'bg-indigo-400' : 'bg-indigo-600'
                        }`}
                        style={{ height: `${heightPercent}%` }}
                      ></div>
                    </div>
                    <span className="text-[9px] text-indigo-200 mt-1">{day}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Log sleep manual form */}
          <form onSubmit={handleSleepSubmit} className="space-y-3.5 pt-1">
            <h4 className="text-2xs font-semibold text-gray-400 uppercase tracking-wider">Yeni Uyku Girişi</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] text-gray-400 mb-1 font-medium">Süre (Saat)</label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={sleepDuration}
                  onChange={(e) => setSleepDuration(e.target.value)}
                  className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1 font-medium">Tarih</label>
                <input
                  type="date"
                  required
                  value={sleepDate}
                  onChange={(e) => setSleepDate(e.target.value)}
                  className="w-full px-3 py-1.5 border text-xs rounded-xl bg-gray-50 dark:bg-gray-850 border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-gray-400 mb-1.5 font-medium">Uyku Kalitesi</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'good', label: 'Derin & Rahat' },
                  { id: 'average', label: 'Normal / Bölünmüş' },
                  { id: 'poor', label: 'Yetersiz / Uykusuz' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSleepQuality(item.id as any)}
                    className={`py-1.5 px-1 text-[10px] font-semibold rounded-xl border transition-all ${
                      sleepQuality === item.id
                        ? 'bg-indigo-600 border-indigo-600 text-white'
                        : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2 px-4 rounded-xl shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Moon className="w-3.5 h-3.5" /> Uyku Kaydını Ekle
            </button>
          </form>

          {/* List sleep logs */}
          <div className="max-h-24 overflow-y-auto space-y-1.5 pr-1 pt-1.5 border-t border-gray-100 dark:border-gray-800">
            {sleepLogs.length === 0 ? (
              <p className="text-2xs text-gray-400 italic">Henüz uyku kaydı girilmedi.</p>
            ) : (
              sleepLogs.slice().reverse().map((log) => (
                <div
                  key={log.id}
                  className="flex justify-between items-center text-2xs p-2 bg-gray-50 dark:bg-gray-850 rounded-lg border border-gray-100/40 dark:border-gray-800/20"
                >
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-gray-700 dark:text-gray-300 font-mono">{log.duration} Saat</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-semibold uppercase ${
                        log.quality === 'good'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400'
                          : log.quality === 'average'
                          ? 'bg-amber-50 text-amber-600 border border-amber-100 dark:bg-amber-950/20 dark:text-amber-400'
                          : 'bg-rose-50 text-rose-600 border border-rose-100 dark:bg-rose-950/20 dark:text-rose-400'
                      }`}
                    >
                      {log.quality === 'good' ? 'Rahat' : log.quality === 'average' ? 'Bölünmüş' : 'Yetersiz'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400 font-mono">
                      {new Date(log.date).toLocaleDateString('tr-TR')}
                    </span>
                    <button
                      onClick={() => onRemoveSleepLog(log.id)}
                      className="text-gray-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
