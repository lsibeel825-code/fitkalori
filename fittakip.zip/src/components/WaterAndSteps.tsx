/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WaterLog, StepLog, UserProfile } from '../types';
import { CupSoda, GlassWater, Footprints, Flame, Trophy, Route, Plus, Trash2, Calendar } from 'lucide-react';

interface WaterAndStepsProps {
  profile: UserProfile;
  waterLogs: WaterLog[];
  stepLogs: StepLog[];
  onAddWater: (amount: number) => void;
  onRemoveWaterLog: (id: string) => void;
  onUpdateSteps: (steps: number) => void;
}

export default function WaterAndSteps({
  profile,
  waterLogs,
  stepLogs,
  onAddWater,
  onRemoveWaterLog,
  onUpdateSteps,
}: WaterAndStepsProps) {
  const [customWater, setCustomWater] = useState<string>('200');
  const [customSteps, setCustomSteps] = useState<string>('1500');

  // Calculate today's water sum
  const todayWaterTotal = waterLogs.reduce((sum, log) => sum + log.amount, 0);
  const waterTarget = profile.dailyWaterTarget || 2000;
  const waterPercentage = Math.min(100, Math.round((todayWaterTotal / waterTarget) * 100));

  // Get current day's steps (YYYY-MM-DD format)
  const todayStr = new Date().toISOString().split('T')[0];
  const todayStepsLog = stepLogs.find((l) => l.date === todayStr);
  const todaySteps = todayStepsLog ? todayStepsLog.steps : 0;
  const stepTarget = profile.dailyStepTarget || 8000;
  const stepPercentage = Math.min(100, Math.round((todaySteps / stepTarget) * 100));

  // Step metrics calculations
  const distanceKm = parseFloat(((todaySteps * 0.00075)).toFixed(2)); // ~75cm step size
  const caloriesBurned = Math.round(todaySteps * 0.04); // ~0.04 kcal per step

  const handleAddCustomWater = () => {
    const amt = parseInt(customWater, 10);
    if (amt > 0) {
      onAddWater(amt);
    }
  };

  const handleAddSteps = () => {
    const stp = parseInt(customSteps, 10);
    if (stp > 0) {
      onUpdateSteps(todaySteps + stp);
    }
  };

  const handleSetStepsDirectly = (val: number) => {
    if (val >= 0) {
      onUpdateSteps(val);
    }
  };

  return (
    <div className="space-y-6" id="water-steps-container">
      {/* Title block */}
      <div className="flex items-center space-x-3 border-b pb-4 border-gray-100 dark:border-gray-800">
        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/50 rounded-xl text-emerald-600 dark:text-emerald-400">
          <CupSoda className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 font-sans tracking-tight">
            Günlük Sıvı & Hareket Takibi
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
            Su tüketiminizi ve adım istatistiklerinizi güncel tutun
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* WATER TRACKER PANEL */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-5">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <GlassWater className="w-4.5 h-4.5 text-sky-500" /> Su Takibi
            </h3>
            <span className="text-xs font-mono font-medium text-sky-500 bg-sky-50 dark:bg-sky-950/30 px-2 py-0.5 rounded-full border border-sky-100 dark:border-sky-900/50">
              %{waterPercentage} Tamamlandı
            </span>
          </div>

          {/* Water Glass Animation Container */}
          <div className="flex items-center justify-around py-2">
            <div className="relative w-28 h-36 border-4 border-gray-300 dark:border-gray-700 rounded-b-2xl overflow-hidden shadow-inner flex flex-col justify-end">
              {/* Animated wave layers */}
              <div
                className="bg-sky-400/80 dark:bg-sky-500/80 transition-all duration-700 relative w-full"
                style={{ height: `${waterPercentage}%` }}
              >
                {waterPercentage > 0 && (
                  <div className="absolute top-0 left-0 right-0 h-2 bg-sky-300/60 animate-pulse"></div>
                )}
              </div>

              {/* Central text overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-xl font-black font-mono text-gray-800 dark:text-white drop-shadow-sm">
                  {todayWaterTotal}
                </span>
                <span className="text-[10px] font-medium text-gray-500 dark:text-gray-300 uppercase">
                  / {waterTarget} ml
                </span>
              </div>
            </div>

            {/* Quick logs metrics */}
            <div className="text-right space-y-1">
              <p className="text-xs text-gray-400">Bugün Tüketilen</p>
              <p className="text-2xl font-bold font-mono text-gray-800 dark:text-gray-100">
                {todayWaterTotal} ml
              </p>
              <div className="text-2xs text-gray-400">
                {todayWaterTotal >= waterTarget ? (
                  <span className="text-emerald-500 font-semibold flex items-center justify-end gap-1">
                    <Trophy className="w-3 h-3" /> Günlük hedefe ulaşıldı!
                  </span>
                ) : (
                  <span>Kalan: <strong className="font-mono">{waterTarget - todayWaterTotal} ml</strong></span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Intake Log Buttons */}
          <div className="space-y-3">
            <label className="block text-2xs font-semibold text-gray-400 uppercase tracking-wider">Hızlı Ekle</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onAddWater(250)}
                className="py-2.5 px-3 border border-gray-200 dark:border-gray-800 rounded-xl bg-gray-50 hover:bg-sky-50 dark:bg-gray-850 dark:hover:bg-sky-950/20 text-gray-700 dark:text-gray-200 hover:text-sky-600 dark:hover:text-sky-400 text-xs font-semibold font-mono active:scale-95 transition-all flex flex-col items-center gap-1"
              >
                <span>+250 ml</span>
                <span className="text-[9px] font-normal text-gray-400">Bardak</span>
              </button>
              <button
                onClick={() => onAddWater(500)}
                className="py-2.5 px-3 border border-gray-200 dark:border-gray-800 rounded-xl bg-gray-50 hover:bg-sky-50 dark:bg-gray-850 dark:hover:bg-sky-950/20 text-gray-700 dark:text-gray-200 hover:text-sky-600 dark:hover:text-sky-400 text-xs font-semibold font-mono active:scale-95 transition-all flex flex-col items-center gap-1"
              >
                <span>+500 ml</span>
                <span className="text-[9px] font-normal text-gray-400">Şişe</span>
              </button>
              <button
                onClick={() => onAddWater(750)}
                className="py-2.5 px-3 border border-gray-200 dark:border-gray-800 rounded-xl bg-gray-50 hover:bg-sky-50 dark:bg-gray-850 dark:hover:bg-sky-950/20 text-gray-700 dark:text-gray-200 hover:text-sky-600 dark:hover:text-sky-400 text-xs font-semibold font-mono active:scale-95 transition-all flex flex-col items-center gap-1"
              >
                <span>+750 ml</span>
                <span className="text-[9px] font-normal text-gray-400">Matara</span>
              </button>
            </div>

            {/* Custom add */}
            <div className="flex gap-2 items-center pt-1.5">
              <div className="relative flex-1">
                <input
                  type="number"
                  value={customWater}
                  onChange={(e) => setCustomWater(e.target.value)}
                  className="w-full pl-3 pr-10 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 font-mono"
                  placeholder="Miktar girin"
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-gray-400 font-mono font-bold">ML</span>
              </div>
              <button
                onClick={handleAddCustomWater}
                className="py-2 px-3 bg-sky-500 hover:bg-sky-600 text-white rounded-xl text-xs font-bold active:scale-95 transition-all flex items-center gap-1 shrink-0 shadow-sm shadow-sky-500/10"
              >
                <Plus className="w-3.5 h-3.5" /> Ekle
              </button>
            </div>
          </div>

          {/* Today's log history */}
          <div className="pt-2 border-t border-gray-100 dark:border-gray-800 space-y-2">
            <h4 className="text-2xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3" /> Bugünkü Geçmiş
            </h4>
            {waterLogs.length === 0 ? (
              <p className="text-2xs text-gray-400 italic">Henüz su girişi yapılmadı.</p>
            ) : (
              <div className="max-h-24 overflow-y-auto space-y-1.5 scrollbar-thin scrollbar-thumb-gray-200 pr-1">
                {waterLogs.slice().reverse().map((log) => {
                  const logTime = new Date(log.timestamp).toLocaleTimeString('tr-TR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  });
                  return (
                    <div
                      key={log.id}
                      className="flex justify-between items-center text-2xs p-2 bg-gray-50 dark:bg-gray-850 rounded-lg border border-gray-100/30 dark:border-gray-800/20"
                    >
                      <span className="font-semibold text-sky-600 dark:text-sky-400 font-mono">
                        +{log.amount} ml
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 font-mono">{logTime}</span>
                        <button
                          onClick={() => onRemoveWaterLog(log.id)}
                          className="text-gray-400 hover:text-rose-500 transition-colors p-0.5"
                          title="Sil"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* STEP COUNTER PANEL */}
        <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-5 shadow-sm space-y-5">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-sans flex items-center gap-1.5">
              <Footprints className="w-4.5 h-4.5 text-emerald-500" /> Adım Sayar
            </h3>
            <span className="text-xs font-mono font-medium text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/50">
              %{stepPercentage} Tamamlandı
            </span>
          </div>

          {/* Circular Step Progress Indicator */}
          <div className="flex items-center justify-around py-1">
            <div className="relative w-32 h-32 flex items-center justify-center">
              {/* SVG Ring */}
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="52"
                  className="stroke-gray-100 dark:stroke-gray-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="52"
                  className="stroke-emerald-500 dark:stroke-emerald-400 transition-all duration-700 ease-out"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 52}`}
                  strokeDashoffset={`${2 * Math.PI * 52 * (1 - stepPercentage / 100)}`}
                  strokeLinecap="round"
                />
              </svg>
              {/* Inner steps overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <Footprints className="w-5 h-5 text-emerald-500 animate-bounce" />
                <span className="text-lg font-black font-mono text-gray-800 dark:text-white mt-1">
                  {todaySteps.toLocaleString('tr-TR')}
                </span>
                <span className="text-[9px] font-semibold text-gray-400 uppercase">
                  Hedef: {stepTarget.toLocaleString('tr-TR')}
                </span>
              </div>
            </div>

            {/* Metrics cards */}
            <div className="space-y-3 shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-amber-50 dark:bg-amber-950/20 text-amber-500 border border-amber-100 dark:border-amber-900/50 rounded-lg">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-sans">Aktif Yakılan</p>
                  <p className="text-sm font-bold font-mono text-gray-800 dark:text-gray-100">
                    {caloriesBurned} <span className="text-[10px] font-normal text-gray-400">kcal</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-blue-50 dark:bg-blue-950/20 text-blue-500 border border-blue-100 dark:border-blue-900/50 rounded-lg">
                  <Route className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-sans">Mesafe</p>
                  <p className="text-sm font-bold font-mono text-gray-800 dark:text-gray-100">
                    {distanceKm} <span className="text-[10px] font-normal text-gray-400">km</span>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Add actions / sensors simulated logs */}
          <div className="space-y-3">
            <label className="block text-2xs font-semibold text-gray-400 uppercase tracking-wider">Hızlı Adım Ekle</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleSetStepsDirectly(todaySteps + 1000)}
                className="py-1.5 px-2 border border-gray-100 dark:border-gray-800 rounded-lg bg-gray-50 hover:bg-emerald-50 dark:bg-gray-850 dark:hover:bg-emerald-950/20 text-gray-700 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 text-2xs font-semibold font-mono transition-all active:scale-95"
              >
                +1,000 Adım
              </button>
              <button
                onClick={() => handleSetStepsDirectly(todaySteps + 3000)}
                className="py-1.5 px-2 border border-gray-100 dark:border-gray-800 rounded-lg bg-gray-50 hover:bg-emerald-50 dark:bg-gray-850 dark:hover:bg-emerald-950/20 text-gray-700 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 text-2xs font-semibold font-mono transition-all active:scale-95"
              >
                +3,000 Koşu
              </button>
              <button
                onClick={() => handleSetStepsDirectly(todaySteps + 5000)}
                className="py-1.5 px-2 border border-gray-100 dark:border-gray-800 rounded-lg bg-gray-50 hover:bg-emerald-50 dark:bg-gray-850 dark:hover:bg-emerald-950/20 text-gray-700 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 text-2xs font-semibold font-mono transition-all active:scale-95"
              >
                +5,000 Yürüyüş
              </button>
            </div>

            {/* Custom step add */}
            <div className="flex gap-2 items-center pt-1.5">
              <div className="relative flex-1">
                <input
                  type="number"
                  value={customSteps}
                  onChange={(e) => setCustomSteps(e.target.value)}
                  className="w-full pl-3 pr-14 py-2 border rounded-xl bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  placeholder="Adım girin"
                />
                <span className="absolute right-3 top-2.5 text-[9px] text-gray-400 font-mono font-bold uppercase">Adım</span>
              </div>
              <button
                onClick={handleAddSteps}
                className="py-2 px-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold active:scale-95 transition-all flex items-center gap-1 shrink-0 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Adım Ekle
              </button>
            </div>
          </div>

          {/* Quick calibration resets */}
          <div className="flex justify-between text-2xs text-gray-400 pt-2 border-t border-gray-100 dark:border-gray-800">
            <span>Bugünkü İlerleme Durumu:</span>
            <button
              onClick={() => handleSetStepsDirectly(0)}
              className="text-gray-400 hover:text-rose-500 transition-colors font-semibold"
            >
              Adımları Sıfırla
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
